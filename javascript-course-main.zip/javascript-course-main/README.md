## JavaScript Course Materials
📚 Watch the course here: https://youtu.be/EerdGm-ehJQ

1. [Exercise solutions](1-exercise-solutions)
2. [Copy of the code](2-copy-of-code) at the end of each lesson

🎓 A certificate of completion is available for this course here: https://courses.supersimple.dev/courses/javascript