# Exercises
![Exercises 1](https://user-images.githubusercontent.com/70604577/229872995-4f102a89-1b86-49a9-8f6b-62f1ba8badb5.png)
![Exercises 1 2](https://user-images.githubusercontent.com/70604577/229872993-3e04a4cb-c67c-4d0b-83fd-40904f047bf4.png)
